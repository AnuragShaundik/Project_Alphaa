import Account from "./Account";
import "./App.css";

function App() {
  return (
    <div>
      <Account
        name="Elon"
        salary={55000}
        expr={5}
        summary={`Tech genius with bold ideas and Mars dreams.`}
        image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpSmpnivwYyWMZFgUvFWC92cnAW4q11jCa1A&s"
      />

      <Account
        name="Trump"
        salary={98000}
        expr={10}
        summary={`Donald Trump is like that one guy at a family wedding... 😄`}
        image="https://fortune.com/img-assets/wp-content/uploads/2025/05/GettyImages-2215203788-e1747765808923.jpg?w=1440&q=75"
      />
    </div>
  );
}

export default App;
