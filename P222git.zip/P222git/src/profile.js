function Profile() {
  const description = [
    { pid: 1, name: "Harry", salary: 890000 },
    { pid: 2, name: "smith", salary: 990000 },
    { pid: 3, name: "Trump", salary: 90000 },
    { pid: 4, name: "mark", salary: 770000 },
    { pid: 5, name: "Elon", salary: 90000 },
    { pid: 6, name: "kelvin", salary: 9870000 },
  ];

  return (
    <div>
      <h1>Hello Profile</h1>

      {description.map((item) => (
        <div key={item.pid}>
          <p>Name: {item.name}</p>
          <p>Salary: {item.salary}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}

export default Profile;
