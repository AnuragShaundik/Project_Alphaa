import React, { useState } from "react";

function One() {
  var [name, setName] = useState("Raghav");
  var [num, setNum] = useState(10);
  var [val, setVal] = useState(true);
  var [sq, setSq] = useState(1);
  var [col, setCol] = useState("yellow");
  var [obj, setObj] = useState({
    id: "123",
    ename: "Anurag",
    city: "Prayagraj",
  });

  var change = () => setName("Anurag");
  var change2 = () => setNum(num + 10);
  var change3 = () => setVal(!val);
  var change4 = () => setSq(sq * 2);
  var change5 = () => setCol("green");
  var change6 = () =>
    setObj({
      id: "222",
      ename: "Radha",
      city: "Pune",
    });

  return (
    <div>
      <h1>Hello from One {name}</h1>
      <button onClick={change}>Change Name</button>

      <h1>{num}</h1>
      <button onClick={change2}>Change Number</button>

      <h1>{val ? "True" : "False"}</h1>
      <button onClick={change3}>Change Value</button>

      <h1>{sq}</h1>
      <button onClick={change4}>Twice</button>

      <h2>
        {obj.id}, {obj.ename}, {obj.city}
      </h2>
      <button onClick={change6}>Change Object</button>
      <div
        style={{
          height: "200px",
          width: "400px",
          backgroundColor: col,
        }}
      >
        Jai Shree Ram
      </div>

      <button onClick={change5}>Change Color</button>
    </div>
  );
}

export default One;
