import "./About.css";

function About() {
  const products = [
    {
      pid: 1,
      pname: "Wireless Mouse",
      price: 799,
      imglink:
        "https://t3.ftcdn.net/jpg/06/11/67/78/360_F_611677850_HguXRoZYQWu7ekpl1MWxMTiSY4kKTmPT.jpg",
      description: "Ergonomic wireless mouse with smooth tracking",
    },
    {
      pid: 2,
      pname: "Mechanical Keyboard",
      price: 2499,
      imglink: "https://cdn.mos.cms.futurecdn.net/E7oKNpmCRUGvQSzWqAkUXF.jpg",
      description: "RGB mechanical keyboard with blue switches",
    },
    {
      pid: 3,
      pname: "USB-C Charger",
      price: 1299,
      imglink:
        "https://recomp.in/wp-content/uploads/2023/10/Unifire_UNPD-20W-USB-C.jpg.webp",
      description: "Fast charging USB-C power adapter",
    },
    {
      pid: 4,
      pname: "Bluetooth Headphones",
      price: 3499,
      imglink:
        "https://unixindia.in/cdn/shop/files/01_34af94b9-40d7-4956-805e-0cb7df907ef7.jpg?v=1747994450",
      description: "Noise cancelling over-ear bluetooth headphones",
    },
    {
      pid: 5,
      pname: "Smart Watch",
      price: 5999,
      imglink:
        "https://m.media-amazon.com/images/I/71XA0QCW5lL._AC_UF1000,1000_QL80_.jpg",
      description: "Fitness tracking smartwatch with heart rate monitor",
    },
    {
      pid: 6,
      pname: "Laptop Stand",
      price: 1499,
      imglink:
        "https://bestor.in/cdn/shop/files/Artboard_2_bc78dec9-766f-40d7-a7cc-2f40394b1c77.jpg?v=1719316028&width=1500",
      description: "Adjustable aluminum laptop stand",
    },
    {
      pid: 7,
      pname: "Webcam",
      price: 2299,
      imglink:
        "https://rukminim2.flixcart.com/image/480/480/xif0q/webcam/h/f/w/720p-web-camera-for-video-calling-conferencing-pc-laptop-desktop-original-imah3d7bag8ub3mx.jpeg?q=90",
      description: "Full HD webcam for video conferencing",
    },
    {
      pid: 8,
      pname: "External Hard Drive",
      price: 4999,
      imglink:
        "https://i.pinimg.com/736x/67/f2/f1/67f2f1586275526d060efdc794041a90.jpg",
      description: "1TB portable external hard drive",
    },
    {
      pid: 9,
      pname: "Pen Drive",
      price: 699,
      imglink:
        "https://m.media-amazon.com/images/I/51uBDIyAZlL._AC_UF1000,1000_QL80_.jpg",
      description: "64GB USB 3.0 pen drive",
    },
    {
      pid: 10,
      pname: "Bluetooth Speaker",
      price: 1999,
      imglink:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkzm330_QXVLpQJnT6jKW3ixSYYI9Vka9t6Q&s",
      description: "Portable bluetooth speaker with deep bass",
    },
    {
      pid: 11,
      pname: "Gaming Mouse Pad",
      price: 499,
      imglink:
        "https://bestor.in/cdn/shop/files/61DLwWE6-SL._SL1100.jpg?v=1713464820&width=1445",
      description: "Large gaming mouse pad with anti-slip base",
    },
    {
      pid: 12,
      pname: "Power Bank",
      price: 1799,
      imglink:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSe-MGNvObx385BbQrNW_IEb2BJlT0Lgn2MmQ&s",
      description: "10000mAh fast charging power bank",
    },
    {
      pid: 13,
      pname: "Wireless Earbuds",
      price: 2999,
      imglink:
        "https://www.boat-lifestyle.com/cdn/shop/files/ACCG6DS7WDJHGWSH_0.png?v=1727669669",
      description: "True wireless earbuds with charging case",
    },
    {
      pid: 14,
      pname: "Monitor",
      price: 11999,
      imglink:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlEDSntYmV1Rp_wtIMm54NCN9_OHWGdrVCdA&s",
      description: "24-inch Full HD LED monitor",
    },
    {
      pid: 15,
      pname: "Graphics Tablet",
      price: 4599,
      imglink:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkdGREf2tN7A1AUBeOapaC5CwxISAvG7Zp9Q&s",
      description: "Drawing tablet for designers and artists",
    },
    {
      pid: 16,
      pname: "Router",
      price: 2699,
      imglink:
        "https://media.wired.com/photos/67b789076813fc3f11f2ff37/master/w_1600%2Cc_limit/Asus-RT-BE58U-Wi-Fi-Router-(front)-Reviewer-Photo-SOURCE-Simon-Hill.jpg",
      description: "Dual band WiFi router for home use",
    },
    {
      pid: 17,
      pname: "Smart Bulb",
      price: 899,
      imglink:
        "https://www.crompton.co.in/cdn/shop/files/bulb1.png?v=1692612581",
      description: "WiFi enabled smart LED bulb",
    },
    {
      pid: 18,
      pname: "Tripod Stand",
      price: 1299,
      imglink:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlHk5Exj_n1pC1emgA23veXLiru-BWKuSdnQ&s",
      description: "Flexible tripod stand for mobile and camera",
    },
    {
      pid: 19,
      pname: "Microphone",
      price: 3499,
      imglink:
        "https://m.media-amazon.com/images/I/61XZgWJwg0L._AC_UF1000,1000_QL80_.jpg",
      description: "USB condenser microphone for recording",
    },
    {
      pid: 20,
      pname: "VR Headset",
      price: 3999,
      imglink:
        "https://i.pcmag.com/imagery/reviews/063ep8ylYBmRGSXkZ0i0Qer-1.fit_lim.size_919x518.v1728608548.jpg",
      description: "Virtual reality headset for immersive gaming",
    },
    // baaki products same rahenge
  ];

  return (
    <div>
      <h1>Hello from About</h1>

      <div className="cards">
        {products.map((pro) => (
          <div className="card" key={pro.pid}>
            <img src={pro.imglink} alt={pro.pname} className="i" />
            <h2>{pro.pname}</h2>
            <p>{pro.description}</p>
            <h3>₹{pro.price}</h3>
          </div>
        ))}
      </div>
    </div>
  );
}

export default About;
