import "./Account.css";
function Account(prop) {
  return (
    <div className="profile">
      <img src={prop.image} className="i" />
      <h1>{prop.name}</h1>
      <h3>Experience : {prop.expr} years </h3>
      <p>{prop.summary}</p>
      <h3>current salary : {prop.salary}</h3>
    </div>
  );
}
export default Account;
